from crew.crew_config import recruiting_crew

__all__ = ['recruiting_crew']