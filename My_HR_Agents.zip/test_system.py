"""
System testing script for AI Recruiting System
Run this to verify all components are working
"""
import requests
import json
import time
from pathlib import Path


BASE_URL = "http://localhost:8000"


def print_section(title):
    """Print section header"""
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)


def test_health():
    """Test health endpoint"""
    print_section("Test 1: Health Check")
    
    try:
        response = requests.get(f"{BASE_URL}/health")
        data = response.json()
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 200 and data.get('status') == 'healthy':
            print("✓ Health check passed")
            return True
        else:
            print("✗ Health check failed")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_stats():
    """Test stats endpoint"""
    print_section("Test 2: System Statistics")
    
    try:
        response = requests.get(f"{BASE_URL}/stats")
        data = response.json()
        
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 200:
            print("✓ Stats endpoint working")
            return True
        else:
            print("✗ Stats endpoint failed")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_agents_status():
    """Test agents status"""
    print_section("Test 3: Agent Status")
    
    try:
        response = requests.get(f"{BASE_URL}/agents/status")
        data = response.json()
        
        print(f"Total Agents: {len(data.get('agents', {}))}")
        
        for agent_name, agent_info in data.get('agents', {}).items():
            print(f"\n{agent_name}:")
            print(f"  Role: {agent_info.get('role')}")
            print(f"  Status: {agent_info.get('status')}")
        
        if response.status_code == 200:
            print("\n✓ All agents are active")
            return True
        else:
            print("\n✗ Agent check failed")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_mcp_tools():
    """Test MCP tools"""
    print_section("Test 4: MCP Tools")
    
    try:
        response = requests.get(f"{BASE_URL}/mcp/tools")
        data = response.json()
        
        print(f"Total Tools: {data.get('total_tools')}")
        
        for tool in data.get('tools', []):
            print(f"\n{tool.get('name')}:")
            print(f"  Description: {tool.get('description')}")
        
        if response.status_code == 200:
            print("\n✓ All MCP tools registered")
            return True
        else:
            print("\n✗ MCP tools check failed")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_create_job():
    """Test job creation"""
    print_section("Test 5: Create Job Posting")
    
    job_data = {
        "job_id": f"TEST-{int(time.time())}",
        "title": "Test Python Developer",
        "description": "This is a test job posting for system verification",
        "requirements": [
            "Python programming",
            "API development",
            "Database knowledge"
        ],
        "required_skills": [
            "Python",
            "FastAPI",
            "MongoDB"
        ],
        "experience_required": 3,
        "location": "Remote",
        "salary_range": "$80,000 - $120,000",
        "department": "Engineering",
        "employment_type": "full-time"
    }
    
    try:
        response = requests.post(f"{BASE_URL}/jobs/", json=job_data)
        data = response.json()
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 200 and data.get('success'):
            print(f"✓ Job created: {job_data['job_id']}")
            return job_data['job_id']
        else:
            print("✗ Job creation failed")
            return None
    except Exception as e:
        print(f"✗ Error: {e}")
        return None


def test_get_jobs():
    """Test getting jobs"""
    print_section("Test 6: Get Job Postings")
    
    try:
        response = requests.get(f"{BASE_URL}/jobs/")
        data = response.json()
        
        print(f"Total Jobs: {data.get('count', 0)}")
        
        if data.get('jobs'):
            print("\nSample Job:")
            job = data['jobs'][0]
            print(f"  ID: {job.get('job_id')}")
            print(f"  Title: {job.get('title')}")
            print(f"  Skills: {', '.join(job.get('required_skills', []))}")
        
        if response.status_code == 200:
            print("\n✓ Jobs retrieved successfully")
            return True
        else:
            print("\n✗ Failed to get jobs")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_resume_upload():
    """Test resume upload (requires sample resume)"""
    print_section("Test 7: Resume Upload")
    
    # Check if sample resume exists
    sample_files = list(Path('.').glob('*.pdf')) + list(Path('.').glob('*.docx'))
    
    if not sample_files:
        print("⚠️  No sample resume found (*.pdf or *.docx)")
        print("   Please add a sample resume to test this feature")
        return False
    
    resume_file = sample_files[0]
    print(f"Using file: {resume_file}")
    
    try:
        with open(resume_file, 'rb') as f:
            files = {'file': (resume_file.name, f, 'application/pdf')}
            response = requests.post(f"{BASE_URL}/upload/resume", files=files)
        
        data = response.json()
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 200 and data.get('success'):
            print(f"\n✓ Resume processed successfully")
            print(f"  Candidate: {data.get('candidate_name')}")
            print(f"  Email: {data.get('candidate_email')}")
            print(f"  Score: {data.get('overall_score', 0):.2f}")
            return data.get('candidate_email')
        else:
            print("\n✗ Resume upload failed")
            return None
    except Exception as e:
        print(f"✗ Error: {e}")
        return None


def test_get_candidates():
    """Test getting candidates"""
    print_section("Test 8: Get Candidates")
    
    try:
        response = requests.get(f"{BASE_URL}/candidates/")
        data = response.json()
        
        print(f"Total Candidates: {data.get('count', 0)}")
        
        if data.get('candidates'):
            print("\nSample Candidate:")
            candidate = data['candidates'][0]
            print(f"  Name: {candidate.get('name')}")
            print(f"  Email: {candidate.get('email')}")
            print(f"  Skills: {', '.join(candidate.get('skills', []))}")
            print(f"  Score: {candidate.get('score', 0)}")
        
        if response.status_code == 200:
            print("\n✓ Candidates retrieved successfully")
            return True
        else:
            print("\n✗ Failed to get candidates")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_shortlist_candidate(candidate_email, job_id):
    """Test candidate shortlisting"""
    print_section("Test 9: Shortlist Candidate")
    
    if not candidate_email or not job_id:
        print("⚠️  Skipping (no candidate or job available)")
        return False
    
    try:
        response = requests.post(
            f"{BASE_URL}/candidates/{candidate_email}/shortlist/{job_id}"
        )
        data = response.json()
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {json.dumps(data, indent=2)}")
        
        if response.status_code == 200 and data.get('success'):
            print("\n✓ Candidate shortlisted successfully")
            if data.get('interview_details'):
                print(f"  Interview Time: {data['interview_details'].get('scheduled_time')}")
                print(f"  Meeting Link: {data['interview_details'].get('meeting_link')}")
            return True
        else:
            print("\n✗ Shortlisting failed")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def test_get_interviews():
    """Test getting interviews"""
    print_section("Test 10: Get Interviews")
    
    try:
        response = requests.get(f"{BASE_URL}/interviews/")
        data = response.json()
        
        print(f"Total Interviews: {data.get('count', 0)}")
        
        if data.get('interviews'):
            print("\nSample Interview:")
            interview = data['interviews'][0]
            print(f"  Candidate: {interview.get('candidate_id')}")
            print(f"  Job: {interview.get('job_id')}")
            print(f"  Time: {interview.get('scheduled_time')}")
            print(f"  Status: {interview.get('status')}")
        
        if response.status_code == 200:
            print("\n✓ Interviews retrieved successfully")
            return True
        else:
            print("\n✗ Failed to get interviews")
            return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False


def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("  AI RECRUITING SYSTEM - COMPREHENSIVE TEST")
    print("="*60)
    print("\nStarting tests...\n")
    
    results = {}
    
    # Basic tests
    results['health'] = test_health()
    time.sleep(1)
    
    results['stats'] = test_stats()
    time.sleep(1)
    
    results['agents'] = test_agents_status()
    time.sleep(1)
    
    results['mcp_tools'] = test_mcp_tools()
    time.sleep(1)
    
    # Functional tests
    job_id = test_create_job()
    results['create_job'] = job_id is not None
    time.sleep(1)
    
    results['get_jobs'] = test_get_jobs()
    time.sleep(1)
    
    candidate_email = test_resume_upload()
    results['resume_upload'] = candidate_email is not None
    time.sleep(1)
    
    results['get_candidates'] = test_get_candidates()
    time.sleep(1)
    
    # Integration tests
    if candidate_email and job_id:
        results['shortlist'] = test_shortlist_candidate(candidate_email, job_id)
        time.sleep(1)
    else:
        results['shortlist'] = False
    
    results['get_interviews'] = test_get_interviews()
    
    # Summary
    print_section("TEST SUMMARY")
    
    total = len(results)
    passed = sum(1 for v in results.values() if v)
    failed = total - passed
    
    print(f"\nTotal Tests: {total}")
    print(f"Passed: {passed} ✓")
    print(f"Failed: {failed} ✗")
    print(f"Success Rate: {(passed/total*100):.1f}%")
    
    print("\nDetailed Results:")
    for test_name, result in results.items():
        status = "✓ PASS" if result else "✗ FAIL"
        print(f"  {test_name}: {status}")
    
    print("\n" + "="*60)
    
    if passed == total:
        print("🎉 All tests passed! System is fully operational.")
    elif passed >= total * 0.7:
        print("⚠️  Most tests passed. Check failed tests above.")
    else:
        print("❌ Multiple tests failed. Please check the system configuration.")
    
    print("="*60 + "\n")


if __name__ == "__main__":
    print("\nMake sure the server is running: python main.py")
    input("Press Enter to start tests...")
    run_all_tests()