# Interview data model
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from bson import ObjectId


class Interview(BaseModel):
    """Interview data model"""
    
    id: Optional[ObjectId] = Field(alias="_id", default=None)
    candidate_id: str
    job_id: str
    recruiter_id: Optional[str] = None
    scheduled_time: datetime
    duration_minutes: int = 60
    interview_type: str = "technical"  # technical, hr, managerial, final
    meeting_link: Optional[str] = None
    location: Optional[str] = None
    status: str = "scheduled"  # scheduled, completed, cancelled, rescheduled
    notes: Optional[str] = None
    feedback: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    reminder_sent: bool = False
    
    class Config:
        populate_by_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}


class InterviewCreate(BaseModel):
    """Schema for creating an interview"""
    candidate_id: str
    job_id: str
    scheduled_time: datetime
    duration_minutes: int = 60
    interview_type: str = "technical"
    meeting_link: Optional[str] = None
    location: Optional[str] = None


class InterviewUpdate(BaseModel):
    """Schema for updating an interview"""
    scheduled_time: Optional[datetime] = None
    status: Optional[str] = None
    notes: Optional[str] = None
    feedback: Optional[str] = None


class InterviewResponse(BaseModel):
    """Response model for interview"""
    id: str
    candidate_id: str
    job_id: str
    scheduled_time: datetime
    duration_minutes: int
    interview_type: str
    status: str
    meeting_link: Optional[str] = None
    created_at: datetime