from api.routes import upload, jobs, candidates, interviews

__all__ = ['upload', 'jobs', 'candidates', 'interviews']