from config.settings import settings

__all__ = ['settings']